
  /*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
    
import express from "express";
import { device } from "../controllers/device.js";

const router = express.Router();

// Pages and HTML form submissions
router.get("/", device.index);
router.get("/index", device.index);
router.get("/add", device.add);
router.post("/insert", device.insert);
router.post("/index", device.insert);
router.get("/edit/:id", device.edit);
router.post("/update/:id", device.update);
router.get("/delete/:id", device.delete);
router.post("/delete/:id", device.delete);

// Existing device endpoints
router.get("/devices", device.all);
router.post("/devices", device.insert);
router.get("/devices/:id", device.show);
router.put("/devices/:id", device.update);
router.delete("/devices/:id", device.delete);
router.get("/devices/:id/edit", device.edit);
router.post("/devices/:id/update", device.update);
router.post("/devices/:id/delete", device.delete);

export default router;
